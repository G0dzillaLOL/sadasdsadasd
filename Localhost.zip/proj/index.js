const app = require("express")();
const path = require("path");
const cors = require('cors');
const fs = require('fs');

app.use(cors());

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "/index.html"));
});

app.get("/app.js", (req, res) => {
    res.sendFile(path.join(__dirname, "/app.js"));
});

app.get("/app.css", (req, res) => {
    res.sendFile(path.join(__dirname, "/app.css"));
});

app.get("/sentry.js", (req, res) => {
    res.sendFile(path.join(__dirname, "/sentry.js"));
});

app.get("/zombs_wasm.wasm", (req, res) => {
    res.sendFile(path.join(__dirname, "/zombs_wasm.wasm"));
});

app.get("/alt_zombs_wasm.wasm", (req, res) => {
    res.sendFile(path.join(__dirname, "/alt_zombs_wasm.wasm"));
});

app.get("/spots2.js", (req, res) => {
    res.sendFile(path.join(__dirname, "/spots2.js"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-orange/zombie-orange-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-orange/zombie-orange-t10-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-purple/zombie-purple-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-purple/zombie-purple-t10-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-yellow/zombie-yellow-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-yellow/zombie-yellow-t10-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-red/zombie-red-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-red/zombie-red-t10-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-blue/zombie-blue-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-blue/zombie-blue-t10-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t2-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t2-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t3-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t3-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t4-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t4-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t5-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t5-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t6-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t6-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t7-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t7-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t8-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t8-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t9-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t9-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t9-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t9-weapon.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t10-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t10-base.svg"));
});

app.get("/asset/image/entity/zombie-green/zombie-green-t10-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-green/zombie-green-t10-weapon.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t1-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t2-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t3-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t4-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t5-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t6-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t7-base.svg"));
});

app.get("/asset/image/entity/slow-trap/slow-trap-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/slow-trap/slow-trap-t8-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t1-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t1-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t2-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t2-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t3-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t3-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t4-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t4-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t5-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t5-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t6-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t6-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t7-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t7-weapon.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t8-base.svg"));
});

app.get("/asset/image/entity/pet-miner/pet-miner-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-miner/pet-miner-t8-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t1-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t1-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t2-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t2-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t2-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t3-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t3-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t3-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t4-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t4-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t4-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t5-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t5-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t5-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t6-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t6-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t6-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t7-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t7-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t7-weapon.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t8-base.svg"));
});

app.get("/asset/image/entity/pet-carl/pet-carl-t8-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-carl/pet-carl-t8-weapon.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t1-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t1-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t1-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t1-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t2-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t2-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t2-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t2-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t3-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t3-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t3-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t3-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t4-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t4-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t4-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t4-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t5-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t5-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t5-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t5-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t6-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t6-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t6-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t6-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t7-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t7-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t7-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t7-middle.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t8-base.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t8-head.svg"));
});

app.get("/asset/image/entity/melee-tower/melee-tower-t8-middle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/melee-tower/melee-tower-t8-middle.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-projectile.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-projectile.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t1-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t1-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t2-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t2-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t3-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t3-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t4-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t4-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t5-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t5-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t6-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t6-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t7-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t7-head.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t8-base.svg"));
});

app.get("/asset/image/entity/arrow-tower/arrow-tower-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/arrow-tower/arrow-tower-t8-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-projectile.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-projectile.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t1-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t1-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t2-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t2-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t3-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t3-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t4-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t4-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t5-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t5-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t6-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t6-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t7-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t7-head.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t8-base.svg"));
});

app.get("/asset/image/entity/mage-tower/mage-tower-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/mage-tower/mage-tower-t8-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t1-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t1-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t2-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t2-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t3-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t3-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t4-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t4-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t5-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t5-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t6-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t6-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t7-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t7-head.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t8-base.svg"));
});

app.get("/asset/image/entity/gold-mine/gold-mine-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-mine/gold-mine-t8-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-projectile.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-projectile.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t1-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t1-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t2-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t2-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t3-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t3-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t4-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t4-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t5-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t5-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t6-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t6-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t7-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t7-head.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t8-base.svg"));
});

app.get("/asset/image/entity/cannon-tower/cannon-tower-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/cannon-tower/cannon-tower-t8-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-projectile.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-projectile.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t1-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t1-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t2-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t2-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t3-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t3-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t4-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t4-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t5-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t5-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t6-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t6-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t7-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t7-head.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t8-base.svg"));
});

app.get("/asset/image/entity/bomb-tower/bomb-tower-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/bomb-tower/bomb-tower-t8-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t1-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t1-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t1-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t1-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t1-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t2-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t2-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t2-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t2-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t2-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t3-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t3-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t3-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t3-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t3-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t4-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t4-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t4-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t4-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t4-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t5-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t5-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t5-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t5-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t5-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t6-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t6-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t6-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t6-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t6-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t7-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t7-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t7-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t7-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t7-head.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t8-base.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t8-claw.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t8-claw.svg"));
});

app.get("/asset/image/entity/harvester/harvester-t8-head.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/harvester/harvester-t8-head.svg"));
});

app.get("/asset/image/entity/door/door-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t1-base.svg"));
});

app.get("/asset/image/entity/door/door-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t2-base.svg"));
});

app.get("/asset/image/entity/door/door-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t3-base.svg"));
});

app.get("/asset/image/entity/door/door-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t4-base.svg"));
});

app.get("/asset/image/entity/door/door-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t5-base.svg"));
});

app.get("/asset/image/entity/door/door-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t6-base.svg"));
});

app.get("/asset/image/entity/door/door-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t7-base.svg"));
});

app.get("/asset/image/entity/door/door-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/door/door-t8-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t1-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t2-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t3-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t4-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t5-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t6-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t7-base.svg"));
});

app.get("/asset/image/entity/gold-stash/gold-stash-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/gold-stash/gold-stash-t8-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t1-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t2-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t2-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t3-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t3-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t4-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t4-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t5-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t5-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t6-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t6-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t7-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t7-base.svg"));
});

app.get("/asset/image/entity/wall/wall-t8-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/wall/wall-t8-base.svg"));
});

app.get("/asset/image/entity/hat-horns/hat-horns-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/hat-horns/hat-horns-base.svg"));
});

app.get("/asset/image/entity/pet-ghost/pet-ghost-projectile.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-ghost/pet-ghost-projectile.svg"));
});

app.get("/asset/image/entity/pet-ghost/pet-ghost-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/pet-ghost/pet-ghost-t1-base.svg"));
});

app.get("/asset/image/entity/player/player-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-base.svg"));
});

app.get("/asset/image/entity/player/player-bomb-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-hands.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t1.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t2.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t3.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t4.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t5.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t6.svg"));
});

app.get("/asset/image/entity/player/player-bomb-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bomb-t7.svg"));
});

app.get("/asset/image/entity/player/player-bow-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t1.svg"));
});

app.get("/asset/image/entity/player/player-bow-t1-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t1-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t2.svg"));
});

app.get("/asset/image/entity/player/player-bow-t2-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t2-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t3.svg"));
});

app.get("/asset/image/entity/player/player-bow-t3-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t3-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t4.svg"));
});

app.get("/asset/image/entity/player/player-bow-t4-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t4-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t5.svg"));
});

app.get("/asset/image/entity/player/player-bow-t5-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t5-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t6.svg"));
});

app.get("/asset/image/entity/player/player-bow-t6-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t6-hands.svg"));
});

app.get("/asset/image/entity/player/player-bow-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t7.svg"));
});

app.get("/asset/image/entity/player/player-bow-t7-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-bow-t7-hands.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t1.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t2.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t3.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t4.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t5.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t6.svg"));
});

app.get("/asset/image/entity/player/player-pickaxe-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-pickaxe-t7.svg"));
});

app.get("/asset/image/entity/player/player-spear-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t1.svg"));
});

app.get("/asset/image/entity/player/player-spear-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t2.svg"));
});

app.get("/asset/image/entity/player/player-spear-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t3.svg"));
});

app.get("/asset/image/entity/player/player-spear-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t4.svg"));
});

app.get("/asset/image/entity/player/player-spear-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t5.svg"));
});

app.get("/asset/image/entity/player/player-spear-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t6.svg"));
});

app.get("/asset/image/entity/player/player-spear-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/player/player-spear-t7.svg"));
});

app.get("/asset/image/entity/heal-towers-spell/heal-towers-spell-particle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/heal-towers-spell/heal-towers-spell-particle.svg"));
});

app.get("/asset/image/entity/neutral/neutral-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/neutral/neutral-t1-base.svg"));
});

app.get("/asset/image/entity/neutral/neutral-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/neutral/neutral-t1-weapon.svg"));
});

app.get("/asset/image/entity/neutral-camp/neutral-camp-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/neutral-camp/neutral-camp-base.svg"));
});

app.get("/asset/image/entity/zombie-boss/zombie-boss-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-boss/zombie-boss-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-boss/zombie-boss-t1-weapon.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-boss/zombie-boss-t1-weapon.svg"));
});

app.get("/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-base.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-base.svg"));
});

app.get("/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-bow-hands.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-bow-hands.svg"));
});

app.get("/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-bow.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/entity/zombie-ranged-green/zombie-ranged-green-t1-bow.svg"));
});

app.get("/asset/image/map/map-grass.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/map/map-grass.png"));
});

app.get("/asset/image/map/map-tree.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/map/map-tree.svg"));
});

app.get("/asset/image/map/map-stone.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/map/map-stone.svg"));
});

app.get("/asset/image/ui/entities/map-tree.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/map-tree.svg"));
});

app.get("/asset/image/misc/changelog-9july-preview.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/changelog-9july-preview.png"));
});

app.get("/asset/image/misc/discord-icon.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/discord-icon.png"));
});

app.get("/asset/image/misc/facebook-icon.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/facebook-icon.png"));
});

app.get("/asset/image/misc/twitter-card.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/twitter-card.png"));
});

app.get("/asset/image/misc/twitter-icon.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/twitter-icon.png"));
});

app.get("/asset/image/misc/youtube-icon-btn.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/youtube-icon-btn.png"));
});

app.get("/asset/image/misc/youtube-icon.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/misc/youtube-icon.png"));
});

app.get("/asset/image/ui/ui-time-bar.png", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/ui-time-bar.png"));
});

app.get("/asset/image/ui/icons/icons-party.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/icons/icons-party.svg"));
});

app.get("/asset/image/ui/icons/icons-settings.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/icons/icons-settings.svg"));
});

app.get("/asset/image/ui/icons/icons-shop.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/icons/icons-shop.svg"));
});

app.get("/asset/image/ui/entities/entities-wall.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-wall.svg"));
});

app.get("/asset/image/ui/entities/entities-tree.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-tree.svg"));
});

app.get("/asset/image/ui/entities/entities-stone.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-stone.svg"));
});

app.get("/asset/image/ui/entities/entities-door.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-door.svg"));
});

app.get("/asset/image/ui/entities/entities-slow-trap.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-slow-trap.svg"));
});

app.get("/asset/image/ui/entities/entities-arrow-tower.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-arrow-tower.svg"));
});

app.get("/asset/image/ui/entities/entities-cannon-tower.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-cannon-tower.svg"));
});

app.get("/asset/image/ui/entities/entities-melee-tower.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-melee-tower.svg"));
});

app.get("/asset/image/ui/entities/entities-bomb-tower.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-bomb-tower.svg"));
});

app.get("/asset/image/ui/entities/entities-mage-tower.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-mage-tower.svg"));
});

app.get("/asset/image/ui/entities/entities-gold-mine.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-gold-mine.svg"));
});

app.get("/asset/image/ui/entities/entities-harvester.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-harvester.svg"));
});

app.get("/asset/image/ui/entities/entities-gold-stash.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/entities/entities-gold-stash.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bomb-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bomb-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-bow-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-bow-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-hat-horns.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-hat-horns.svg"));
});

app.get("/asset/image/ui/inventory/inventory-heal-towers-spell.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-heal-towers-spell.svg"));
});

app.get("/asset/image/ui/inventory/inventory-health-potion.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-health-potion.svg"));
});

app.get("/asset/image/ui/inventory/inventory-invulnerable.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-invulnerable.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-carl-t8.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-carl-t8.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-ghost-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-ghost-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-health-potion.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-health-potion.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pet-miner-t8.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pet-miner-t8.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-pickaxe-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-pickaxe-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t8.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t8.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t9.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t9.svg"));
});

app.get("/asset/image/ui/inventory/inventory-shield-t10.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-shield-t10.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t1.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t1.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t2.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t2.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t3.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t3.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t4.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t4.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t5.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t5.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t6.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t6.svg"));
});

app.get("/asset/image/ui/inventory/inventory-spear-t7.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-spear-t7.svg"));
});

app.get("/asset/image/ui/inventory/inventory-timeout.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-timeout.svg"));
});

app.get("/asset/image/ui/inventory/inventory-whistle.svg", (req, res) => {
    res.sendFile(path.join(__dirname, "/asset/image/ui/inventory/inventory-whistle.svg"));
});

app.listen(1000, () => console.log("running"));